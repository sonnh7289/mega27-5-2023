//
//  userModel.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

struct UserModel {
    var color: UserColor!
    var idNote : Int!
    var data : String!
    var type : String!

    init() {
        self.color = nil
        self.idNote = 0
        self.data = ""
        self.type = ""
    }
    init(object: Any) {
        if let dic: Dictionary<String, Any> = object as? Dictionary<String, Any> {
            if let color = dic["color"] as? UserColor {
                self.color = color
            } else {
                self.color = nil
            }
            if let idNote = dic["idNote"] as? Int {
                self.idNote = idNote
            } else {
                self.idNote = 0
            }
            if let data = dic["data"] as? String {
                self.data = data
            } else {
                self.data = ""
            }
            if let type = dic["type"] as? String {
                self.type = type
            } else {
                self.type = ""
            }
        } else {
            self.color = nil
            self.idNote = 0
            self.data = ""
            self.type = ""
        }
    }
}
struct UserColor {
    var a: Float!
    var b: Int!
    var g: Int!
    var r: Int!
    
    init(object: Any) {
        if let dic: Dictionary<String, Any> = object as? Dictionary<String, Any> {
            if let a = dic["a"] as? Float {
                self.a = a
            } else {
                self.a = nil
            }
            if let b = dic["b"] as? Int {
                self.b = b
            } else {
                self.b = 0
            }
            if let g = dic["g"] as? Int {
                self.g = g
            } else {
                self.g = 0
            }
            if let r = dic["r"] as? Int {
                self.r = r
            } else {
                self.r = 0
            }
        } else {
            self.a = 0
            self.b = 0
            self.g = 0
            self.r = 0
        }
    }
}
