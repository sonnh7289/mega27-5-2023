//
//  LoginModel.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 30/09/2023.
//

import Foundation

struct LoginModel: Codable {
    let jwt: String?
    let message : String?
    let status : Int?
    let user : DataUser?
}

struct DataUser: Codable {
    let Avarta: String?
    let AvtProfile: String?
    let df_color: ColorModel?
    let df_screen: String?
    let gmail: String?
    let id: Int?
    let name: String?
    let password_2: String?
    let statesLogin: Bool?
}
struct ColorModel: Codable {
    let a: Float?
    let b: Int?
    let g: Int?
    let r: Int?
}
