//
//  Configs.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

final class Configs {
    
    static let share = Configs()
    
    private init() {}
    
    var env: Enviroment {
        #if ENDPOINT_DEBUG
        return .production
        #elseif ENDPOINT_RELEASE
        return .production
        #endif
        return .production
    }
}
