//
//  Enviroment.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

enum Enviroment {
    case staging
    case production
}

extension Enviroment {
    var baseURL: String {
        switch self {
        case .staging:
            return "https://lhvn.online/"
        case .production:
            return "https://lhvn.online/"
        }
    }
    var IPURL: String {
        switch self {
        case .staging:
            return "https://ipinfo.io/json"
        case .production:
            return "https://ipinfo.io/json"
        }
    }
}
