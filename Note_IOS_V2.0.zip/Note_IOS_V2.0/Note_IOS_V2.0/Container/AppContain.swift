//
//  AppContain.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 27/09/2023.
//

import Foundation

struct AppContain {
    static let titleArray = [
        "SamNote",
        "Easily Shared",
        "Security and privacy",
        "Flexible notes",
        "Stylus Pen"
    ]
    static let subTitleArray = [
        "Welcome to the Notebook app!\nStart recording and storing your ideas now!",
        "A versatile and user-friendly note that can be easily shared",
        "Protect data with password and encryption to ensure the safety of personal information.",
        "Create diverse notes with text, images, audio, and video to capture ideas and information.",
        "Pen feature on Note provides a natural writing and drawing experience, from taking notes to creating digital art."
    ]
    static let imageArray = [
        AppContant.art1,
        AppContant.art2,
        AppContant.art3,
        AppContant.art4,
        AppContant.art5
    ]
}

