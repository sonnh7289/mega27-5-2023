//
//  AppConstant.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 27/09/2023.
//

import UIKit

struct AppContant {
    static let art1 = UIImage(named: "image1")
    static let art2 = UIImage(named: "image2")
    static let art3 = UIImage(named: "image3")
    static let art4 = UIImage(named: "image4")
    static let art5 = UIImage(named: "image5")
    
    static let page = UIImage(named: "page")
    static let pageSelected = UIImage(named: "pageSelected")
    
    static let mainScreen = UIScreen.main.bounds.height
}

