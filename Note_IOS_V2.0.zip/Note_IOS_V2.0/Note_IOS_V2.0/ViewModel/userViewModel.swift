//
//  userViewModel.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 06/10/2023.
//

import Foundation
import RxSwift
import RxCocoa

class UserViewModel: NSObject {
    var resultUser = BehaviorRelay<[UserModel]>(value: [])
    override init() {
        super.init()
        bindingData()
    }
    func bindingData() {
        
    }
    func requestJson(url: String) {
        let url = URL(string: url)
        let session = URLSession.shared
        session.dataTask(with: url!) { (data, res, err) in
            if err == nil {
                do {
                    if let result:Dictionary<String, Any> = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? Dictionary<String, Any> {
                        var userArray:Array<UserModel> = []
                        if let notes: Array<Any> = result["notes"] as? Array<Any> {
                            for i in notes {
                                let user = UserModel(object: i)
                                userArray.append(user)
                            }
                            self.resultUser.accept(userArray)
                        }
                    }
                } catch {
                    
                }
                
            }
        }
    }
}
