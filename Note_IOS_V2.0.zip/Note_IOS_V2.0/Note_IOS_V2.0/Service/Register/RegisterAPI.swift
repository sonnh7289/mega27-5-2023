//
//  RegisterAPI.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 01/10/2023.
//

import Foundation

//class RegisterAPI: BaseAPI<RegisterServiceConfiguration> {
//    static let shared = RegisterAPI()
//
//    func getIP(completionHandler: @escaping (Result<IPAddress, ServiceError>) -> Void) {
//        fetchData(configuration: .getIP,
//                  responseType: IPAddress.self) { result in
//        completionHandler(result)
//        }
//    }
//}
