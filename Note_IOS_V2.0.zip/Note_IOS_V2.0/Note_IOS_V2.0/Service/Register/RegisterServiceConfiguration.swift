//
//  RegisterServiceConfiguration.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 01/10/2023.
//

import Foundation

enum RegisterServiceConfiguration {
    case getIP
}

extension RegisterServiceConfiguration {
    var baseURL: String {
        switch self {
        case .getIP:
            return Constant.Server.IPURL
        }
    }
    var path: String {
        switch self {
        case .getIP:
            return ""
        }
    }
    var method: HTTPMethod {
        switch self {
        case .getIP:
            return .get
        }
    }
    var task: Task {
        switch self {
        case .getIP:
            return .requestPlain
        }
    }
    var headers: [String: String]? {
        switch self {
        case .getIP:
            return [:]
        }
    }
    var data: Data? {
        switch self {
        case .getIP:
            return nil
        }
    }
}
