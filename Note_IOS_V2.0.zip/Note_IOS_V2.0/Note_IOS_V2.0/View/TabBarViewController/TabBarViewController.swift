//
//  TabBarViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 05/10/2023.
//

import UIKit

class TabBarViewController: UIViewController {
    @IBOutlet weak var contenView: UIView!
    @IBOutlet weak var homeStackView: UIStackView!
    @IBOutlet weak var chatStackView: UIStackView!
//    @IBOutlet weak var btnHome: UIButton!
//    @IBOutlet weak var btnCalender: UIButton!
//    @IBOutlet weak var btnChat: UIButton!
//    @IBOutlet weak var btnProfile: UIButton!
    
    func ViewConfig() {
        homeStackView.spacing = UIScreen.main.bounds.size.height * 44 / 932
        chatStackView.spacing = UIScreen.main.bounds.size.height * 44 / 932
//        btnHome.setImage(UIImage(named: "iconHomeDen"), for: .normal)
//        btnCalender.setImage(UIImage(named: "iconLichDen"), for: .normal)
//        btnHome.setImage(UIImage(named: "iconTNDen"), for: .normal)
//        btnHome.setImage(UIImage(named: "iconPrrofileDen"), for: .normal)
    }
    @IBAction func clickTabBar(_ sender: UIButton) {
        let tag = sender.tag
        //print("tag: \(tag)")
        if tag == 1 {
            let home = HomeListViewController(nibName: "HomeListViewController", bundle: nil)
            self.addChild(home)
            self.contenView.addSubview(home.view)
            home.view.translatesAutoresizingMaskIntoConstraints = false  // Tắt translatesAutoresizingMaskIntoConstraints cho home.view

            // Thiết lập ràng buộc giữa home.view và contentView
            NSLayoutConstraint.activate([
                home.view.topAnchor.constraint(equalTo: self.contenView.topAnchor),
                home.view.leadingAnchor.constraint(equalTo: self.contenView.leadingAnchor),
                home.view.trailingAnchor.constraint(equalTo: self.contenView.trailingAnchor),
                home.view.bottomAnchor.constraint(equalTo: self.contenView.bottomAnchor)
            ])
            home.didMove(toParent: self)
        } else if tag == 2 {
            let schedule = ScheduleViewController(nibName: "ScheduleViewController", bundle: nil)
            self.addChild(schedule)
            self.contenView.addSubview(schedule.view)
            schedule.didMove(toParent: self)
        } else if tag == 3 {
            let chat = ChatViewController(nibName: "ChatViewController", bundle: nil)
            self.addChild(chat)
            self.contenView.addSubview(chat.view)
            chat.didMove(toParent: self)
        } else {
            let profile = ProfileViewController(nibName: "ProfileViewController", bundle: nil)
            self.addChild(profile)
            self.contenView.addSubview(profile.view)
            profile.didMove(toParent: self)
        }
    }
}
