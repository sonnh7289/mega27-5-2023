//
//  LoginWithViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import UIKit

class LoginWithViewController: UIViewController {
    
    @IBOutlet weak var btnStackView: UIStackView!
    @IBOutlet weak var signUpLable: UILabel!
    
    func viewConfig() {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        btnStackView.spacing = AppContant.mainScreen * 43 / 932
        signUpLable.adjustsFontSizeToFitWidth = true
        signUpLable.minimumScaleFactor = 0.1
        signUpLable.isUserInteractionEnabled = true
        signUpLable.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapSignUp)))
    }
}
