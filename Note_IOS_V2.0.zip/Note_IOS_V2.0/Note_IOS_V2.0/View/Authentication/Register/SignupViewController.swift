//
//  SignupViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import UIKit

class SignupViewController: UIViewController {
    
    var isCheck: Bool = false
    
    @IBOutlet weak var emailStackView: UIStackView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var passView: UIView!
    @IBOutlet weak var retypeView: UIView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    @IBOutlet weak var retypeTextField: UITextField!
    @IBOutlet weak var showpassButton: UIButton!
    @IBOutlet weak var showretypeButton: UIButton!
    @IBOutlet weak var rememberButton: UIButton!
    @IBOutlet weak var btnStackView: UIStackView!
    @IBOutlet weak var signInLable: UILabel!
    
    func viewConfig() {
        emailStackView.spacing = AppContant.mainScreen * 25 / 932
        btnStackView.spacing = AppContant.mainScreen * 30 / 932
        emailView.layer.cornerRadius = AppContant.mainScreen * 10 / 932
        passView.layer.cornerRadius = AppContant.mainScreen * 10 / 932
        retypeView.layer.cornerRadius = AppContant.mainScreen * 10 / 932
        showpassButton.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
        showretypeButton.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
        rememberButton.setBackgroundImage(UIImage(named: "tickBox"), for: UIControl.State.normal)
        signInLable.adjustsFontSizeToFitWidth = true
        signInLable.minimumScaleFactor = 0.1
        signInLable.isUserInteractionEnabled = true
        signInLable.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapSignIn)))
        passTextField.isSecureTextEntry = true
        retypeTextField.isSecureTextEntry = true
        hideKeyboard()
    }
}
