//
//  OnboardingViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 27/09/2023.
//

import UIKit

class OnboardingViewController: UIViewController {
    
    @IBOutlet weak var onBoardCollectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!

}
