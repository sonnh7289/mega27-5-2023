//
//  LoginViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import UIKit
import Toast_Swift

class LoginViewController: UIViewController {
    
    var isCheck: Bool = false
    
    @IBOutlet weak var emailStackView: UIStackView!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var viewPass: UIView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    @IBOutlet weak var showPass: UIButton!
    @IBOutlet weak var rememberPass: UIButton!
    @IBOutlet weak var forgotLable: UILabel!
    @IBOutlet weak var signUpLable: UILabel!
    @IBOutlet weak var btnStackView: UIStackView!
    
    func viewConfig() {
        viewEmail.layer.cornerRadius = AppContant.mainScreen * 10 / 932
        viewPass.layer.cornerRadius = AppContant.mainScreen * 10 / 932
        emailStackView.spacing = AppContant.mainScreen * 43 / 932
        btnStackView.spacing = AppContant.mainScreen * 30 / 932
        showPass.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
        rememberPass.setBackgroundImage(UIImage(named: "tickBox"), for: UIControl.State.normal)
        forgotLable.adjustsFontSizeToFitWidth = true
        forgotLable.minimumScaleFactor = 0.1
        forgotLable.isUserInteractionEnabled = true
        forgotLable.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapForgot)))
        signUpLable.adjustsFontSizeToFitWidth = true
        signUpLable.minimumScaleFactor = 0.1
        signUpLable.isUserInteractionEnabled = true
        signUpLable.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapSignUp)))
        passTextField.isSecureTextEntry = true
        hideKeyboard()
    }
}
