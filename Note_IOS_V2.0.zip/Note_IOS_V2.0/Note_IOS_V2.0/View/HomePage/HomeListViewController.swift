//
//  HomeListViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 30/09/2023.
//

import UIKit

class HomeListViewController: UIViewController {
    
    @IBOutlet weak var viewAvatar: UIView!
    @IBOutlet weak var imgAvatar: UIImageView!
    @IBOutlet weak var collectionHome: UICollectionView!
    
    func ViewConfig() {
        viewAvatar.layer.cornerRadius = UIScreen.main.bounds.height * 25 / 932
    }
}
