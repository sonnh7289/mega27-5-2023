//
//  HomeCollectionViewCell.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 06/10/2023.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
