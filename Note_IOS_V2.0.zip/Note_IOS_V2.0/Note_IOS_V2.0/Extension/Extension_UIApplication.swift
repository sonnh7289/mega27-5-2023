//
//  Extension_UIApplication.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 30/09/2023.
//

import UIKit

extension UIApplication {
    var mainKeyWindow: UIWindow? {
        if #available(iOS 13, *) {
            return connectedScenes.flatMap { ($0 as? UIWindowScene)?.windows ?? [] }.first {
                $0.isKeyWindow
            }
        } else {
            return keyWindow
        }
    }
}
