//
//  Extension_UINavigation.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 30/09/2023.
//

import UIKit

extension UINavigationController {
    func setRootViewController<T: UIViewController>(viewController vc: UIViewController,
                                                    controllerType: T.Type,
                                                    isAnimated: Bool = true) {
        guard let windown = UIApplication.shared.mainKeyWindow,
              let viewController = vc as? T else {
            fatalError("Could not instantiateViewController with identifier: \(controllerType)")
        }
        windown.rootViewController = UINavigationController.init(rootViewController: viewController)
        windown.makeKeyAndVisible()
    }
}
