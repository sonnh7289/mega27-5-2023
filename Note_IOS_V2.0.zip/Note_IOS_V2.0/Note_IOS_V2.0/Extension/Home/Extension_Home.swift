//
//  Extension_Home.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 05/10/2023.
//

import Foundation
import UIKit

extension HomeListViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        ViewConfig()
        collectionHome.register(UINib(nibName: "HomeCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeCollectionViewCell")
    }
}
