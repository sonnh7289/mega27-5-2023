//
//  Extension_Profile.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 05/10/2023.
//

import Foundation

extension ProfileViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
