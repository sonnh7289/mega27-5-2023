//
//  Extension_String.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

extension String {
    func escape() -> String {
        let allowedCharacters = self.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return allowedCharacters
    }
}
