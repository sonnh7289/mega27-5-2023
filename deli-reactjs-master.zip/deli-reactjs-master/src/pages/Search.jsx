import React from 'react'

function Search() {
  return (
    <div>search</div>
  )
}

export default Search