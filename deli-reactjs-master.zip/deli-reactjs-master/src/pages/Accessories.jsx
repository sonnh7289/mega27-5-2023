import React from 'react'

function Accessories() {
  return (
    <div>Accessories</div>
  )
}

export default Accessories