import React from 'react'

function Contact() {
  return (
    <Helmet title="Liên hệ">
        <div>Contact</div>
    </Helmet>
  )
}

export default Contact