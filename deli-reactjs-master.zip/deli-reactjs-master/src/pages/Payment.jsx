import React from 'react'

function Payment() {
  return (
    <div>Payment</div>
  )
}

export default Payment