//
//  LoveModel.swift
//  ForeverLove
//
//  Created by TTH on 21/07/2023.
//

import Foundation

struct LoveMode : Codable {
    let data : DataLove?
}

struct DataLove : Codable {
    let display_url : String?
}
