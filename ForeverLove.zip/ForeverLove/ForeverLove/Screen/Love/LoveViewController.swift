//
//  LoveViewController.swift
//  ForeverLove
//
//  Created by TTH on 12/07/2023.
//

import UIKit

class LoveViewController: UIViewController{
    
    @IBOutlet weak var txtNameFemale: UITextField!
    @IBOutlet weak var txtNameMale: UITextField!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var imageGirl: UIImageView!
    @IBOutlet weak var imageBoy: UIImageView!
    var currentImageType: ChooseImageType = .boy
    override func viewDidAppear(_ animated: Bool) {
        backgroundView.gradient()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtNameMale.delegate = self
        txtNameFemale.delegate = self
        imageBoy.layer.cornerRadius = UIScreen.main.bounds.size.width * 0.48 / 2
        imageGirl.layer.cornerRadius = UIScreen.main.bounds.size.width * 0.48 / 2
        actionImage()
        
    }
  
    @IBAction func actionStartLove(_ sender: Any) {
//        self.uploadImageToImgBB(image: imageBoy.image!, apiKey: "a07b4b5e0548a50248aecfb194645bac")
        let param: [String: Any] = ["key": "fd81b5da86e162ade162a05220c0eb89",
                                    "image" : imageBoy.image as Any]

        BaseAPI.share.fetchData(urlString: "https://api.imgbb.com/1/upload",
                                method: .post ,
                                parameters: param,
                                responseType: LoveMode.self) { result in
            switch result {
            case .success(let success):
               print(success)
            case .failure(let error):
                print(error)
            }
        }
//        let headers: [String:String] = ["Link_img1": "https://i.ibb.co/Vv9HbWg/anhtam1.jpg" ,
//                                        "Link_img2": "https://i.ibb.co/W22Y9Rx/nu-sinh-ngo-thu-huong.webp"]
//        
//        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/getdata",
//                                method: .get ,
//                                headers: headers,
//                                responseType: <#T##M#>,
//                                completionHandler: <#T##(Result<M, ServiceError>) -> Void#>)
    }
    
    func actionImage(){
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(imageBoyTapped(_:)))
        imageBoy.addGestureRecognizer(tapGesture)
        imageBoy.isUserInteractionEnabled = true
        
        let tapaGesture = UITapGestureRecognizer(target: self,
                                                 action: #selector(imageGirlTapped(_:)))
        imageGirl.addGestureRecognizer(tapaGesture)
        imageGirl.isUserInteractionEnabled = true
    }
    
    @objc func imageBoyTapped(_ sender: UITapGestureRecognizer) {
        currentImageType = .boy
        let ac = UIAlertController(title: "Select Image", message: "Select image from", preferredStyle: .actionSheet)
        let cameraBtn = UIAlertAction(title: "Camera", style: .default) {_ in
            self.showImagePicker(selectedSource: .camera)
        }
        let libaryBtn = UIAlertAction(title: "Libary", style: .default) { _ in
            self.showImagePicker(selectedSource: .photoLibrary)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){ _ in
            self.dismiss(animated: true)
        }
        ac.addAction(cameraBtn)
        ac.addAction(libaryBtn)
        ac.addAction(cancel)
        self.present(ac, animated: true)
        
        
    }
    
    @objc func imageGirlTapped(_ sender: UITapGestureRecognizer) {
        currentImageType = .girl
        let ac = UIAlertController(title: "Select Image", message: "Select image from", preferredStyle: .actionSheet)
        let cameraBtn = UIAlertAction(title: "Camera", style: .default) {_ in
            self.showImagePicker(selectedSource: .camera)
        }
        let libaryBtn = UIAlertAction(title: "Libary", style: .default) { _ in
            self.showImagePicker(selectedSource: .photoLibrary)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){ _ in
            self.dismiss(animated: true)
        }
        ac.addAction(cameraBtn)
        ac.addAction(libaryBtn)
        ac.addAction(cancel)
        self.present(ac, animated: true)
    }
    
    
}
extension LoveViewController : UIPickerViewDelegate,
                               UINavigationControllerDelegate,
                               UIImagePickerControllerDelegate {
    func showImagePicker(selectedSource: UIImagePickerController.SourceType) {
        guard UIImagePickerController.isSourceTypeAvailable(selectedSource) else {
            return
        }
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = selectedSource
        imagePickerController.allowsEditing = false
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            if self.currentImageType == .boy {
                imageBoy.image = selectedImage
            } else {
                imageGirl.image = selectedImage
            }
        } else {
            print("Image not found")
        }
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension LoveViewController : UITextFieldDelegate {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.dismiss(animated: true)
        textField.resignFirstResponder()
        return true
    }
}

enum ChooseImageType {
    case boy
    case girl
}
