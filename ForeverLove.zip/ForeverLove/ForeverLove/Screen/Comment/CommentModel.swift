//
//  CommentModel.swift
//  ForeverLove
//
//  Created by TTH on 12/07/2023.
//

import Foundation


struct CommentModel: Codable {
    let comment : [DataComments]
    let sophantu: Int
    let sotrang: Double
}

struct DataComments: Codable {
    let device_cmt: String
    let dia_chi_ip: String
    let id_comment: Int
    let id_toan_bo_su_kien: Int
    let link_nam_goc: String
    let link_nu_goc: String
    let noi_dung_cmt: String
    let thoi_gian_release: String
}

struct PostComments: Codable {
    let device_cmt : String?
    let id_Comment : Int?
    let id_toan_bo_su_kien : String?
    let imageattach : String?
    let ip_comment : String?
    let link_da_swap : String?
    let noi_dung_cmt : String?
    let so_thu_tu_su_kien : Double?
    let toan_bo_su_kien : Int?
    let id_user: String?
}
