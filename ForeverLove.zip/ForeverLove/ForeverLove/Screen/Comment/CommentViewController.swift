//
//  CommentViewController.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit

class CommentViewController: UIViewController {
    var data : [DataComments] = []
    var isLoadingData = false
    var maxPage: Int = 0
    var currentPage: Int = 1
    
    @IBOutlet weak var commentTableView: UITableView!
    @IBOutlet weak var viewBackground: UIView!
    
    override func viewDidAppear(_ animated: Bool) {
        viewBackground.gradient()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        self.navigationController?.isNavigationBarHidden = true
        commentTableView.register(cellType: CommentTableViewCell.self)
        commentTableView.dataSource = self
        commentTableView.delegate = self
        commentTableView.showsVerticalScrollIndicator = false
        getComment(page: currentPage)
    }

    func getComment(page: Int) {
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/pageComment/\(page)",
                                responseType: CommentModel.self) { result in
            switch result {
            case .success(let success):
                let data = success.comment
                self.data = data
                self.maxPage = Int(success.sotrang)
                self.commentTableView.reloadData()
            case .failure:
                print("sai")
            }
        }
    }
}

extension CommentViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CommentTableViewCell", for: indexPath) as? CommentTableViewCell else {
            return UITableViewCell()
        }
        cell.configCell(model: data[indexPath.row])
        return cell
    }
    
    
}
extension CommentViewController: UITableViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let screenHeight = scrollView.frame.size.height
        
        if !isLoadingData && offsetY > contentHeight - screenHeight {
            isLoadingData = true
            loadMoreData()
        }
    }
    
    func loadMoreData() {
        currentPage += 1
        guard currentPage <= maxPage else { return }
        
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/pageComment/\(self.currentPage)",
                                responseType: CommentModel.self) { result in
            switch result {
            case .success(let success):
                let data = success.comment
                self.data.append(contentsOf: data)
                self.commentTableView.reloadData()
            case .failure(let error):
                print(error)
            }
            self.isLoadingData = false
        }
        
    }
}


