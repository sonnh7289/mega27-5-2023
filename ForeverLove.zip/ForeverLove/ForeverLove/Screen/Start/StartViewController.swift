//
//  StartViewController.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit
import NetworkExtension
import Network

class StartViewController: UIViewController {

    @IBOutlet weak var backgroundView: UIView!
    override func viewDidAppear(_ animated: Bool) {
        backgroundView.gradient()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    



    @IBAction func btnNextHome(_ sender: Any) {
        let homeVC = HomeViewController(nibName: "HomeViewController", bundle: nil)
        let homeNavi = UINavigationController(rootViewController: homeVC)
        homeNavi.tabBarItem = UITabBarItem( title: nil,
                                            image: UIImage(named: "icon_home")?.withRenderingMode(.alwaysOriginal),
                                            selectedImage: UIImage(named: "icon_homeclick")?.withRenderingMode(.alwaysOriginal))
        
        let historyVC = CommingSoonViewController(nibName: "CommingSoonViewController", bundle: nil)
        let historyNavi = UINavigationController(rootViewController: historyVC )
        historyVC.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "icon_history")?.withRenderingMode(.alwaysOriginal),
                                            selectedImage: UIImage(named: "icon_historyclick")?.withRenderingMode(.alwaysOriginal))
        
        let loveVC = LoveViewController(nibName: "LoveViewController", bundle: nil)
        let loveNavi = UINavigationController(rootViewController: loveVC )
        loveVC.tabBarItem = UITabBarItem(title: nil,
                                         image: UIImage(named: "icon_love")?.withRenderingMode(.alwaysOriginal),
                                         selectedImage: UIImage(named: "icon_loveclick")?.withRenderingMode(.alwaysOriginal))
        
        let commentVC = CommentViewController(nibName: "CommentViewController", bundle: nil)
        let commentNavi = UINavigationController(rootViewController: commentVC )
        commentVC.tabBarItem = UITabBarItem(title: nil,
                                            image: UIImage(named: "icon_comment")?.withRenderingMode(.alwaysOriginal),
                                            selectedImage: UIImage(named: "icon_commentclick")?.withRenderingMode(.alwaysOriginal))
        
        //tabbar controller
        let tabbarController = UITabBarController()
        tabbarController.viewControllers = [homeNavi, commentNavi, loveNavi, historyNavi]
        tabbarController.tabBar.tintColor = .black
        tabbarController.view.backgroundColor = .white
        
        
        guard let delegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate,
              let window = delegate.window else { return }
        window.rootViewController = tabbarController
        window.makeKeyAndVisible()
    }
    
   

}
