//
//  HomeViewController.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit

class HomeViewController: UIViewController {
    var data:[HomeModel] = []
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var homeTableView: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        backgroundView.gradient()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        homeTableView.register(cellType: HomeeTableViewCell.self)
        homeTableView.dataSource = self
        homeTableView.delegate = self
        
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/page/1",
                                responseType: [[HomeModel]].self) { result in
            switch result {
            case .success(let success):
                let data = success.flatMap { $0 }
                self.data = data
                self.homeTableView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension HomeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "HomeeTableViewCell", for: indexPath) as? HomeeTableViewCell else {
            return UITableViewCell()
        }
        cell.configCell(model: data[indexPath.row])
        return cell
    }
    
}

extension HomeViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let height = UIScreen.main.bounds.size.width * 200 / 390
        return height
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = HistoryViewController(nibName: "HistoryViewController", bundle: nil)
        vc.index = indexPath.row
        vc.data = data[indexPath.row]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}



