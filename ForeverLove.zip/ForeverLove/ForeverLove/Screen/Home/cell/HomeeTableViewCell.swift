//
//  HomeeTableViewCell.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit
import AlamofireImage

class HomeeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var txtDate: UILabel!
    @IBOutlet weak var imageGirl: UIImageView!
    @IBOutlet weak var imageBoy: UIImageView!
    @IBOutlet weak var imageTitle: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
    }
    func configCell(model: HomeModel) {
        if let url = URL(string: model.link_da_swap ?? ""){
            imageTitle.af.setImage(withURL: url)
        }
        if let url = URL(string: model.link_nam_goc ?? ""){
            imageBoy.af.setImage(withURL: url)
        }
        if let url = URL(string: model.link_nu_goc ?? ""){
            imageGirl.af.setImage(withURL: url)
        }
        labelTitle.text = model.ten_su_kien
     
        let time = self.getFormattedDate(strDate: model.real_time ?? "",
                                         currentFomat: "yyyy-MM-dd, HH:mm:ss",
                                         expectedFromat: "yyyy-MM-dd")
        txtDate.text = time

    }
    
    func getFormattedDate(strDate: String , currentFomat: String, expectedFromat: String) -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = currentFomat

        let date : Date = dateFormatterGet.date(from: strDate) ?? Date()

        dateFormatterGet.dateFormat = expectedFromat
        return dateFormatterGet.string(from: date)
    }
}
