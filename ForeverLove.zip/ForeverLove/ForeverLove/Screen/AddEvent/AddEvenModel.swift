//
//  AddEvenModel.swift
//  ForeverLove
//
//  Created by TTH on 24/07/2023.
//

import Foundation

struct AddEvenModel : Codable {
    let ketqua: String?
}
