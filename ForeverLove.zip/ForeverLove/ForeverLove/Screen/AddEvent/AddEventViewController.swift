//
//  AddEventViewController.swift
//  ForeverLove
//
//  Created by TTH on 20/07/2023.
//

import UIKit

class AddEventViewController: UIViewController {
    let deviceName = UIDevice.current.name
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var uploadImage: UIImageView!
    @IBOutlet weak var txtNumberOrder: UITextField!
    @IBOutlet weak var txtDate: UITextField!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var addEvenScrollView: UIScrollView!
    
    override func viewDidAppear(_ animated: Bool) {
        backgroundView.gradient()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        actionImage()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillShow),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillHide),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
    }
    
    @objc func keyboardWillShow(notification: Notification) {
        guard let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        
        let contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardFrame.height, right: 0)
        addEvenScrollView.contentInset = contentInset
        addEvenScrollView.scrollIndicatorInsets = contentInset
    }

    @objc func keyboardWillHide(notification: Notification) {
        let contentInset = UIEdgeInsets.zero
        addEvenScrollView.contentInset = contentInset
        addEvenScrollView.scrollIndicatorInsets = contentInset
    }
    
    @IBAction func actionBtnClose(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func actionBtnAddEvent(_ sender: Any) {
        let param : [String: Any] = ["noidung_su_kien": txtDescription.text!  ,"so_thu_tu_su_kien": txtNumberOrder.text! ,"device_them_su_kien": deviceName ,"ip_them_su_kien": "192.168.1.1" ,"link_da_swap": "https://i.ibb.co/Vv9HbWg/anhtam1.jpg" ,"thoigian_sukien": txtDate.text! ,"ten_su_kien": txtTitle.text! ]
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/add",
                                method: .post,
                                parameters: param,
                                responseType: AddEvenModel.self) { result in
            switch result {
            case .success(let success):
                let data = success
                print(data)
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func actionImage(){
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(imageBoyTapped(_:)))
        uploadImage.addGestureRecognizer(tapGesture)
        uploadImage.isUserInteractionEnabled = true
        
    }
    
    @objc func imageBoyTapped(_ sender: UITapGestureRecognizer) {
        let ac = UIAlertController(title: "Select Image", message: "Select image from", preferredStyle: .actionSheet)
        let cameraBtn = UIAlertAction(title: "Camera", style: .default) {_ in
            self.showImagePicker(selectedSource: .camera)
        }
        let libaryBtn = UIAlertAction(title: "Libary", style: .default) { _ in
            self.showImagePicker(selectedSource: .photoLibrary)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){ _ in
            self.dismiss(animated: true)
        }
        ac.addAction(cameraBtn)
        ac.addAction(libaryBtn)
        ac.addAction(cancel)
        self.present(ac, animated: true)
        
        
    }
}

extension AddEventViewController : UIPickerViewDelegate,
                                   UINavigationControllerDelegate,
                                   UIImagePickerControllerDelegate {
    func showImagePicker(selectedSource: UIImagePickerController.SourceType) {
        guard UIImagePickerController.isSourceTypeAvailable(selectedSource) else {
            return
        }
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = selectedSource
        imagePickerController.allowsEditing = false
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            uploadImage.image = selectedImage
        } else {
            print("Image not found")
        }
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
