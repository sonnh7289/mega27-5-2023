//
//  SelectedCollectionViewCell.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit

protocol ActionSelectProtocol : AnyObject {
    func buttonTapped(withIndex index: Int)
}

class SelectedCollectionViewCell: UICollectionViewCell {
    weak var delegate: ActionSelectProtocol?
    @IBOutlet weak var btnSelect: UIButton!
    @IBOutlet weak var heightButton: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
    }
    @IBAction func actionBtnSelect(_ sender: UIButton) {
        delegate?.buttonTapped(withIndex: sender.tag)
        
    }
    
    func configCell(model: DataSelected) {
        btnSelect.setTitle(model.name, for: .normal)
        btnSelect.backgroundColor = model.isSelected ? .white : .white
        btnSelect.layer.cornerRadius = model.isSelected ? 24 : 18
        btnSelect.titleLabel?.font = model.isSelected ? .font(style: .bold, size: 24) : .font(style: .regular, size: 18)
        heightButton.constant = model.isSelected ? 48 : 36
    }
}
