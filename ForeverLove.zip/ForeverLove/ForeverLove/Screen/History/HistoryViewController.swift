//
//  HistoryViewController.swift
//  ForeverLove
//
//  Created by TTH on 11/07/2023.
//

import UIKit
import AlamofireImage


class HistoryViewController: UIViewController {
    var dataSelect: [DataSelected] = []
    var dataComment : [CommentEvent] = []
    var index: Int = 1
    var data : HomeModel?
    var timer: Timer?
    var targetDate: Date?
    let calendar = Calendar.current
    let dateComponents: Set<Calendar.Component> = [.day, .hour, .minute, .second]
    let deviceName = UIDevice.current.name
    
    @IBOutlet weak var historyScrollView: UIScrollView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var ImageTitle: UIImageView!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var labelSecs: UILabel!
    @IBOutlet weak var labelMinutes: UILabel!
    @IBOutlet weak var labelHours: UILabel!
    @IBOutlet weak var labelDays: UILabel!
    @IBOutlet weak var backGroundView: UIView!
    @IBOutlet weak var commentTBView: UITableView!
    @IBOutlet weak var selectedCollectionView: UICollectionView!
    @IBOutlet weak var txtFieldComment: UITextField!
    
    deinit {
        timer?.invalidate()
        timer = nil
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        backGroundView.gradient()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadTimer()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        stopTimer()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        hideKeyboardWhenTappedAround()
        
        selectedCollectionView.register(cellType: SelectedCollectionViewCell.self)
        selectedCollectionView.dataSource = self
        selectedCollectionView.delegate = self
        
        commentTBView.register(cellType: CommentEventTBVCell.self)
        commentTBView.delegate = self
        commentTBView.dataSource = self
        commentTBView.showsVerticalScrollIndicator = false
        commentTBView.separatorStyle = .none
        
       
        
        CallApiHistory()
        CallApiComment()
    }
    
  
    
    func CallApiHistory() {
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/\(index)",
                                responseType: [HistoryModel].self) { result in
            switch result {
            case .success(let success) :
                let data = success
                self.dataSelect = data.enumerated().map { index, value in
                    let romanNumeral = (index + 1).convertToRomanNumerals()
                    return DataSelected(name: romanNumeral, model: value)
                }
                self.dataSelect.first?.isSelected = true
                self.selectedInfo(index: 0)
                self.selectedCollectionView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
    func CallApiComment() {
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/comment/\(data?.id_toan_bo_su_kien ?? 1)",
                                responseType: [CommentEvent].self) { result in
            switch result {
            case .success(let success):
                let data = success
                self.dataComment = data
                self.commentTBView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
    
    @IBAction func actionBtnAddMore(_ sender: Any) {
        let vc = AddEventViewController(nibName: "AddEventViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionBtnShare(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func actionPushComment(_ sender: Any) {
        guard txtFieldComment.text != nil else {return}
        let param: [String: Any] = ["noi_dung_cmt": txtFieldComment.text!,
                                    "id_toan_bo_su_kien" : "\(data?.id_toan_bo_su_kien ?? 1)",
                                    "device_cmt" : deviceName,
                                    "ipComment" : "127.0.0.0",
                                    "imageattach": "https://i.ibb.co/PzSqkDR/87dcd50438ca.jpg",
                                    "id_user" : "1"]
        BaseAPI.share.fetchData(urlString: "http://14.225.7.221:8989/lovehistory/comment",
                                method: .post,
                                parameters: param,
                                responseType: PostComments.self) { result in
            switch result {
            case .success(let success):
               print(success)
            case .failure(let error):
                print(error)
            }
            self.CallApiComment()
            self.txtFieldComment.text = nil
            self.commentTBView.reloadData()
        }
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    func loadTimer() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd, HH:mm:ss"
        let fixedTime = self.data?.real_time
        targetDate = dateFormatter.date(from: fixedTime ?? "")
        updateTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.updateTimer()
        }
        RunLoop.current.add(timer!, forMode: .common)
    }
    
    func updateTimer() {
        guard let targetDate = targetDate else { return }
        let currentDate = Date()
        let components = calendar.dateComponents(dateComponents, from: targetDate, to: currentDate)
        
        if let days = components.day {
            labelDays.text = "\(days) "
        }
        if let hours = components.hour {
            labelHours.text = "\(hours) "
        }
        if let minutes = components.minute {
            labelMinutes.text = "\(minutes) "
        }
        if let seconds = components.second {
            labelSecs.text = "\(seconds)"
        }
    }
}

extension HistoryViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        dataSelect.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SelectedCollectionViewCell",
                                                      for: indexPath) as! SelectedCollectionViewCell
        cell.configCell(model: dataSelect[indexPath.row])
        cell.delegate = self
        cell.btnSelect.tag = indexPath.item
        return cell
    }
    
    func selectedInfo(index: Int) {
        let url = URL(string: dataSelect[index].model.link_da_swap ?? "")
        ImageTitle.af.setImage(withURL: url!)
        labelTitle.text = dataSelect[index].model.ten_su_kien
        let time = (dataSelect[index].model.real_time ?? "").getFormattedDate(currentFomat: "yyyy-MM-dd, HH:mm:ss",
                                                                              expectedFromat: "yyyy-MM-dd")
        labelDate.text = time
        labelDescription.text = dataSelect[index].model.noi_dung_su_kien
    }
}

extension HistoryViewController: UICollectionViewDelegate,
                                 UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = UIScreen.main.bounds.size.width / 5
        let height = collectionView.frame.height
        return CGSize(width: width, height: height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}

extension HistoryViewController: ActionSelectProtocol {
    func buttonTapped(withIndex index: Int) {
        dataSelect.forEach { $0.isSelected = false }
        dataSelect[index].isSelected = true
        self.selectedCollectionView.reloadData()
        selectedCollectionView.scrollToItem(at: IndexPath(row: index, section: 0),
                                            at: .centeredHorizontally, animated: true)
        selectedInfo(index: index)
    }
}

extension HistoryViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        dataComment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CommentEventTBVCell", for: indexPath) as? CommentEventTBVCell else {
            return UITableViewCell()
        }
        cell.configCell(model: dataComment[indexPath.row])
        return cell
    }
}

extension HistoryViewController: UITableViewDelegate {
    
}
