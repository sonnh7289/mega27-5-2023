from flask import Flask, render_template, request, jsonify
from googleapiclient.http import MediaFileUpload
from google_apis import create_service
import os
from swap import swap_face
import datetime
import mimetypes
import sys
import base64
import shutil
import tempfile

app = Flask(__name__)

@app.route("/", methods=["GET"])
def home():
    return """
    <h1>Face Swap</h1>
    <form action="/face-swap_up" method="post" enctype="multipart/form-data">
        <input type="file" name="image" accept="image/*" required><br>
        <input type="file" name="video" accept="video/*" required><br>
        <button type="submit">Swap Faces</button>
    </form>
    """

@app.route("/face-swap_up", methods=["POST"])
def face_swap():
    src = request.files["image"]
    dst = request.files["video"]

    output_video_path = "temp/face_swapped.mp4"

    src_path = f"temp/srcimg.{src.filename.split('.')[-1]}"
    src.save(src_path)
    dst_video_path = f"temp/dst_video.{dst.filename.split('.')[-1]}"
    dst.save(dst_video_path)
    
    # src_path = f"temp/srcimg.{src.filename.split('.')[-1]}"
    # src_data = src.read()
    # src_base64 = base64.b64encode(src_data).decode("utf-8")
    # with open(src_path, "wb") as file:
    #     file.write(src_data)

    # dst_video_path = f"temp/dst_video.{dst.filename.split('.')[-1]}"
    # dst_data = dst.read()
    # dst_base64 = base64.b64encode(dst_data).decode("utf-8")
    # with open(dst_video_path, "wb") as file:
    #     file.write(dst_data)

    swap_face(src=src_path, dst=dst_video_path, output=output_video_path)

    try:
        CLIENT_SECRET_FILE = r"client_secret.json"
        API_NAME = "youtube"
        API_VERSION = "v3"
        SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
        youtube_service = create_service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

        video_title = "Swapped Face Video"
        video_description = "Video voi khuon mat swap"
        video_tags = ["face swap"]
        video_category_id = "22"
        video_privacy_status = "public"

        upload_time = datetime.datetime.now().isoformat() + ".000Z"
        request_body = {
            "snippet": {
                "title": video_title,
                "description": video_description,
                "tags": video_tags,
                "categoryId": video_category_id,
            },
            "status": {
                "privacyStatus": video_privacy_status,
                "publishedAt": upload_time,
                "selfDeclaredMadeForKids": False,
            },
            "notifySubscribers": False,
        }

        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_filepath = temp_file.name
            shutil.copyfileobj(open(output_video_path, "rb"), temp_file)

        media_file = MediaFileUpload(temp_filepath)

        response = youtube_service.videos().insert(
            part="snippet,status",
            body=request_body,
            media_body=media_file,
        ).execute()

        uploaded_video_id = response.get("id")
        video_link = f"https://www.youtube.com/watch?v={uploaded_video_id}"
        return {"success": True, "video_id": uploaded_video_id, "video_link": video_link}

    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    app.run(debug=True)
