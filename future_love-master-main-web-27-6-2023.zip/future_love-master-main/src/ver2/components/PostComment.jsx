import React, { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPaperPlane } from "@fortawesome/free-solid-svg-icons";
import { useParams } from "react-router";

function PostComment(props) {
     const { id } = useParams();
     const [data, setData] = useState([]);
     const [deviceName, setDeviceName] = useState("");
     const [dataComment, setDataComment] = useState({
          noi_dung_cmt: "",
          id_toan_bo_su_kien: id, // Set the initial value of id_toan_bo_su_kien to the fetched id
     });
     const ipComment = "192.168.1.24";
     const [commentSent, setCommentSent] = useState(false);

     const handleSubmit = (e) => {
          e.preventDefault();

          const formData = new FormData();
          formData.append("noi_dung_cmt", dataComment.noi_dung_cmt);
          formData.append("device_cmt", deviceName);
          formData.append("id_toan_bo_su_kien", dataComment.id_toan_bo_su_kien);
          formData.append("ipComment", ipComment);
          formData.append("imageattach", dataComment.imageattach);

          if (dataComment.noi_dung_cmt === "") {
               alert("Input something ");
               return;
          }

          axios
               .post("http://14.225.7.221:8989/lovehistory/comment", formData)
               .then((res) => {
                    setDataComment({
                         noi_dung_cmt: "",
                         id_toan_bo_su_kien: id, // Reset the id_toan_bo_su_kien value to the fetched id after successful comment submission
                    });

                    props.fetchDataComment();
                    setCommentSent(true);
               })
               .catch((error) => {
                    console.log("Error posting comment:", error);
               });
     };

     const handleComment = (e) => {
          const { id, value } = e.target;
          setDataComment((prevState) => ({
               ...prevState,
               [id]: value,
          }));
          setCommentSent(false);
     };

     useEffect(() => {
          const getDeviceName = () => {
               const userAgent = navigator.userAgent;
               let deviceName = "Unknown";

               if (userAgent.includes("iPhone")) {
                    deviceName = "iPhone";
               } else if (userAgent.includes("iPad")) {
                    deviceName = "iPad";
               } else if (userAgent.includes("Android")) {
                    deviceName = "Android Device";
               } else if (userAgent.includes("Windows")) {
                    deviceName = "Windows PC";
               } else if (userAgent.includes("Mac")) {
                    deviceName = "Mac";
               } else if (userAgent.includes("Linux")) {
                    deviceName = "Linux PC";
               }

               setDeviceName(deviceName);
          };

          getDeviceName();
     }, []);

     useEffect(() => {
          const fetchData = async () => {
               try {
                    const response = await axios.get(`http://14.225.7.221:8989/lovehistory/${id}`);
                    setData(response.data);
               } catch (error) {
                    console.log("Error fetching Id: " + error);
               }
          };

          fetchData();
     }, [id]);

     return (
          <div className="max-w-full">
               {/* {commentSent && <p className="text-green-500">Bình luận đã được gửi thành công!</p>} */}
               <form onSubmit={handleSubmit}>
                    <div className="flex flex flex-col justify-center mt-20">
                         <div className="relative">
                              <input
                                   name="noi_dung_cmt"
                                   id="noi_dung_cmt"
                                   className="w-full h-20 px-4 py-2 m-2 border  border-gray-300 rounded-l-md focus:outline-none focus:border-pink-500 pr-12"
                                   placeholder="leave a comment..."
                                   onChange={handleComment}
                                   value={dataComment.noi_dung_cmt}
                              />
                              <button
                                   type="submit"
                                   className="absolute h-12 right-0 top-5 bottom-0 background: silver;text-[20px] px-6 py-2 rounded-r-md hover:cursor"
                              >
                                   <FontAwesomeIcon icon={faPaperPlane} className="text-2xl" />
                              </button>
                         </div>

                         <input
                              name="device_cmt"
                              id="device_cmt"
                              className="w-full px-4 py-2 m-2 border border-gray-300 rounded-l-md focus:outline-none focus:border-pink-500 hidden"
                              placeholder="Device"
                              onChange={handleComment}
                              value={deviceName}
                         />
                         <input
                              name="id_toan_bo_su_kien"
                              id="id_toan_bo_su_kien"
                              className="w-full px-4 py-2 m-2 border border-gray-300 rounded-l-md focus:outline-none focus:border-pink-500 hidden"
                              placeholder="Event ID"
                              onChange={handleComment}
                              value={dataComment.id_toan_bo_su_kien}
                         />
                         <input
                              name="ipComment"
                              id="ipComment"
                              className="w-full px-4 py-2 m-2 border border-gray-300 rounded-l-md focus:outline-none focus:border-pink-500 hidden"
                              placeholder="IP Address"
                              onChange={handleComment}
                              value={ipComment}
                         />
                         <input
                              name="imageattach"
                              id="imageattach"
                              className={`w-full px-4 m-2 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:border-pink-500 ${dataComment.imageattach ? '' : 'hidden'}`}
                              type="file"
                              accept="image/*"
                              placeholder="Attach Image"
                              onChange={handleComment}
                         />
                    </div>
               </form>
          </div>
     );

}

export default PostComment;
