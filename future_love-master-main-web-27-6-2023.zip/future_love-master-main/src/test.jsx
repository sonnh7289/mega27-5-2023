import React from "react";
import Historyv2 from "./ver2/page/Historyv2";

function Test() {
  return (
    <div>
      <Historyv2 />
    </div>
  );
}

export default Test;
